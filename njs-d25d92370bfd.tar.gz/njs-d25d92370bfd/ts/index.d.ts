/// <reference path="njs_core.d.ts" />
/// <reference path="njs_modules/crypto.d.ts" />
/// <reference path="njs_modules/fs.d.ts" />
/// <reference path="njs_modules/querystring.d.ts" />

var a = 1;

export a {a}

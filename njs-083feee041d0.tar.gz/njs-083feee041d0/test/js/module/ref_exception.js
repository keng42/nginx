export default {type:typeof undeclared, undeclared};

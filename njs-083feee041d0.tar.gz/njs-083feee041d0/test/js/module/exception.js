import lib from 'lib3.js';

lib.exception();


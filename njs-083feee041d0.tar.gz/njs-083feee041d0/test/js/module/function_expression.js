var foo = (function(){
    return (function f() {})
});

foo()({1:[]})

export default {foo};
